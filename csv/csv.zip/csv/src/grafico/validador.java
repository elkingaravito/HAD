
package grafico;
/*OK*/

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**Clase que procesa la informacion y la valida con expresiones regulares en la carpeta ReporteIES/validacion 
 * @author jorgebeltran
 * @version $Revision: 1.0 $
 */
public class validador {
	public String ruta; 
	public String[][] condiciones;
	public String[][] encabezados;
	public String[][] sufijos;
	public String[][] codigosIES;
	public String[][] codigoPrograma;
	Pattern p2;
	Matcher m2;
	String[] titulos;
	
	public void validador(){
		File expresionesReg=null;
	}
	
	public long escribirValidacionReg(){
		File entrada=new File(ruta);
		File archivoSalida=constantes.archivoValidacion;
		String[][] archivo=leercondiciones(entrada);
		int i=0,i1=0,j=0,lineasvacias=0,celdasvacias=0,entradas=0,columnas=0,llave = 0, repeticiones=0,numFilasMax=0,numFilasMin=0,numFilasProm=0;
		String numerolinea="",nombreColumnas="";
		String[] expresionReg={"^[A-Za-z�������������\\s]*$","^[\\d]*$"};
		String[] tipoDato={"Alfabetico","Numerico"};
		String[][] valoresUnicos=new String[archivo.length][archivo[0].length];
		int[][] porcentaje=new int[2][archivo[0].length];
		int[] longitudMaxima=new int[archivo[0].length];
		int[] longitudPromedio=new int[archivo[0].length];
		int[] numeroValoresUnicos=new int[archivo[0].length];
		int[] camposVacios=new int[archivo[0].length];
		FileWriter fw = null;
		//se crea el archivo de salida 
		try {
			fw = new FileWriter(archivoSalida);
		} catch (IOException e1) {
		
			e1.printStackTrace();
		}
	    BufferedWriter bw = new BufferedWriter(fw);
	    PrintWriter salida = new PrintWriter(bw);
		for(String[] fila:archivo){
			j=0;
			for(String celda:fila){
				repeticiones=0;
				for(int row=0;row<archivo.length;row++){
					if(row!=i){
						try{
						if(row<=archivo.length){
							if(archivo[row][j].equals(celda))repeticiones++;
						}
						}catch(IndexOutOfBoundsException e){
						}
					}
				}
				if(celda.isEmpty())camposVacios[j]++;
				if(repeticiones==0){
					numeroValoresUnicos[j]++;
					if(celda.equals(null))valoresUnicos[i][j]="";
					else valoresUnicos[i][j]=celda;
				}
				if(i==1)longitudMaxima[j]=celda.length();
				if(longitudMaxima[j]<celda.length())longitudMaxima[j]=celda.length();
				longitudPromedio[j]+=celda.length();
				for(int contador=0;contador<2;contador++){
					p2 = Pattern.compile(expresionReg[contador]);
					m2 = p2.matcher(celda.replaceAll("\"", "").replaceAll("'", "").replaceAll(" ", ""));
					if(m2.matches()==true)llave=contador;
				}
				porcentaje[llave][j]++;
				if(celda.trim().equals("")){
					entradas++;
				}
				j++;
				if(i==0){
					columnas=j;
					nombreColumnas+=celda+",";
				}
				if(columnas<j || numFilasMax<j){
					numFilasMax=j;
				}
				if(columnas>j || numFilasMin>j){
					numFilasMin=j;
				}
				numFilasProm+=j;
			}
			if(j==entradas){
				numerolinea+=i+",";
				lineasvacias++;
			}
			i++;
		}
		nombreColumnas= nombreColumnas.substring(0, nombreColumnas.length()-1).replaceAll(",","</td><td>");
		
		if(numerolinea.length() == 0){
		numerolinea= numerolinea.substring(0, 0).replaceAll(",","</td><td>");
		}
		else
		{
			numerolinea= numerolinea.substring(0, numerolinea.length()-1).replaceAll(",","</td><td>");			
		}
		InputStreamReader r = null;
		try {
			r = new InputStreamReader(new FileInputStream(entrada));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try{
			
		
		
		salida.print("<html><head><title>Validaci�n archivo "+entrada.getName()+"</title></head>");
		salida.print("<body>");
		salida.print("<h1>Informe descriptivo de informaci�n</h1>");		
		salida.print("<p>Este informe presenta informaci�n descriptiva del archivo analizado, a fin de identificar su caracteristicas y poder tener criterios de evaluaci�n que indiquen si el archivo se puede utilizar para cruzarse con otros archivos de informaci�n </p>");		
		salida.print("<stron>Nombre del Archivo: "+ruta+"</stron><br><br>");
		salida.print("Codificaci�n: "+r.getEncoding()+"<br><br>");
		long fileSizeInBytes = entrada.length();
		double valorBytes=fileSizeInBytes;
		// Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
		double fileSizeInKB = valorBytes/ 1024;
		// Convert the KB to MegaBytes (1 MB = 1024 KBytes)
		double fileSizeInMB = fileSizeInKB / 1024;
		salida.print("Tama�o <br>Bytes: "+fileSizeInBytes+" <br>KBytes: "+fileSizeInKB+" <br>MBytes: "+fileSizeInMB+"<br><br>");
		salida.print("N�mero de filas: "+i+"<br><br>");
		salida.print("Filas vacias: "+lineasvacias+"<br><br>");
		if(lineasvacias!=0){
			salida.print("Ids Filas vacias: "+numerolinea+"<br><br>");	
		}
		int numFilas=i;
		salida.print("N�mero de columnas: "+columnas+"<br>");
		salida.print("Numero de columnas maximo: "+numFilasMax+"<br>");
		salida.print("Numero de columnas minimo: "+numFilasMin+"<br><br>");
		salida.print("<table border=1><tr><td>Nombres de columnas</td><td>"+nombreColumnas+"</td></tr>");
		i=0;
		for(int[] a:porcentaje){
			salida.print("<tr><td>"+tipoDato[i]+"</td>");
			for(int  b:a){
				salida.print("<td>"+b+"</td>");
			}
			salida.print("</tr>");
			i++;
		}
		salida.print("<tr><td>");
		salida.print("Longitud maxima dato");
		salida.print("</td>");
		for(int g:longitudMaxima){
			salida.print("<td>"+g+"</td>");
		}
		salida.print("</tr>");
		salida.print("<tr><td>Longitud promedio dato</td>");
		for(int g:longitudPromedio){
			salida.print("<td>"+g/numFilas+"</td>");
		}
		salida.print("</tr>");
		salida.print("<tr><td>Valores unicos</td>");
		for(int g:numeroValoresUnicos){
			salida.print("<td>"+g+"</td>");
		}
		salida.print("</tr>");
		salida.print("<tr><td>Campos vacios</td>");
		for(int g:camposVacios){
			salida.print("<td>"+g+"</td>");
		}
		salida.print("</tr></table><br><br>");
		salida.print("<h2>Tabla de valores �nicos por columna </h2> <table border=1>");		
		
		for(String[] g:valoresUnicos){
			salida.print("<tr>");
			for(String k:g){
				salida.print("<td>"+k+"</td>");
			}
			salida.print("</tr>");
		}
		salida.print("</table><br>Los valores null estan repetidos.</body></html>");

		long tm = System.currentTimeMillis();
		tm = System.currentTimeMillis() - tm;
		salida.print("Tiempo transcurrido en el an�lisis" + tm );
		salida.close();
		return tm;

		}catch (Exception e)
		{
			salida.print("Tiempo transcurrido en el an�lisis");
			salida.close();
			return -1;
			
		} 		
	}
	
	
	/*Funci�n que recibe la carpeta o archvio para procesar 
	 * 
	 * */
	public String[][] leercondiciones(File nomcarpeta){
		File archivo = nomcarpeta;
		FileReader fr = null;
		try {
			fr = new FileReader (archivo);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(fr);
		String sL = null;
		List<String> expresiones = new ArrayList<String>();
	    try {
			while((sL=br.readLine())!=null)expresiones.add(sL);
		} catch (IOException e) {
			e.printStackTrace();
		}
		int campos=0;
		String divisor;
		if(!(expresiones.get(0).toString().split(";").length==1)){
			divisor=";";
		}	
		else{	
			divisor=",";	
		}
		campos=expresiones.get(0).toString().split(divisor).length;
		String[][] linea=new String[expresiones.size()][campos];
		for(int i=0;i<expresiones.size();i++){
		 	if(expresiones.get(i)!=null){
		 		linea[i]=expresiones.get(i).toString().split(divisor);	  		
		 	}
		}
		return linea;
	}
}