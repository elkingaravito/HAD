package grafico;

import java.io.File;

public final class constantes {
	  public static final File archivoValidacion =new File("validacion.html");

}
